This is the code for all the tasks I did in the Harvard CS50 python course for beginners
