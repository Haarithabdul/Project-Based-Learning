import emoji

inp = input("Input: ")

print(emoji.emojize(inp, language="alias"))
