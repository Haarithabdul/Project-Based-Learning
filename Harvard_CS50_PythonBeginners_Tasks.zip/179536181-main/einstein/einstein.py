mass = int(input("Mass = ? "))
energy = mass * 300000000**2
energy = str(energy)
print(energy + " joules")
