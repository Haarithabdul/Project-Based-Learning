IndoorVoice = input("Please write something\n").lower()

print(IndoorVoice)
