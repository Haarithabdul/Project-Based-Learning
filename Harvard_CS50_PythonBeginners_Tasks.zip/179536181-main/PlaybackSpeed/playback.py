playback = input("Please write something\n").replace(" ", "...")
print(playback)
